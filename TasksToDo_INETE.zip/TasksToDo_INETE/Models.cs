using System;

namespace TasksToDo_INETE
{
    public class Tarefa
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public DateTime Inicio { get; set; }
        public DateTime Fim { get; set; }
        public bool Responsavel { get; set; }
    }

    public enum TipoNo { Equipa, Funcionario, Tarefa }

    public class DadosNo
    {
        public TipoNo Tipo { get; set; }
        public string Equipa { get; set; }
        public string Funcionario { get; set; }
        public Tarefa Tarefa { get; set; }
    }
}
