using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TasksToDo_INETE
{
    public partial class Form1 : Form
    {
        private DataService dados;
        private List<string> funcionarios;
        private List<string> equipas;
        private string tarefaEmEdicao = null;

        public Form1()
        {
            InitializeComponent();
            dados = new DataService();
            try
            {
                funcionarios = dados.LerFuncionarios();
                equipas = dados.LerEquipas();
                cmbFuncionario.Items.AddRange(funcionarios.Cast<object>().ToArray());
                cmbEquipa.Items.AddRange(equipas.Cast<object>().ToArray());
                CarregarArvore();
            }
            catch (Exception ex)
            {
                TratarErro(ex, "Não foi possível iniciar a aplicação. Verifique os ficheiros de funcionários e equipas.");
                btnAdicionar.Enabled = btnGuardar.Enabled = false;
            }
        }

        private void TratarErro(Exception ex, string mensagem)
        {
            dados.RegistarErro(ex);
            MessageBox.Show(mensagem + Environment.NewLine + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void CarregarArvore()
        {
            tvOrganizacao.Nodes.Clear();
            foreach (string[] p in dados.LerTarefas())
            {
                DateTime inicio, fim;
                if (!DateTime.TryParseExact(p[3], "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out inicio) ||
                    !DateTime.TryParseExact(p[4], "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out fim)) continue;
                AdicionarNos(p[0], p[1], new Tarefa { Nome = p[2], Inicio = inicio, Fim = fim, Responsavel = p[6] == "1", Descricao = p[7] }, p[5] == "1");
            }
            tvOrganizacao.ExpandAll();
        }

        private TreeNode EncontrarNo(string nome, TipoNo tipo, TreeNode raiz)
        {
            foreach (TreeNode n in raiz.Nodes)
            {
                DadosNo d = n.Tag as DadosNo;
                if (d != null && d.Tipo == tipo &&
                    String.Equals(n.Text.Replace(" (Coordenador)", ""), nome, StringComparison.OrdinalIgnoreCase))
                    return n;
            }
            return null;
        }

        private void AdicionarNos(string equipa, string funcionario, Tarefa tarefa, bool coordenador)
        {
            TreeNode noEquipa = EncontrarNo(equipa, TipoNo.Equipa, tvOrganizacao.Nodes);
            if (noEquipa == null)
            {
                noEquipa = new TreeNode(equipa);
                noEquipa.Tag = new DadosNo { Tipo = TipoNo.Equipa, Equipa = equipa };
                tvOrganizacao.Nodes.Add(noEquipa);
            }
            TreeNode noFuncionario = EncontrarNo(funcionario, TipoNo.Funcionario, noEquipa);
            if (noFuncionario == null)
            {
                noFuncionario = new TreeNode(coordenador ? funcionario + " (Coordenador)" : funcionario);
                noFuncionario.Tag = new DadosNo { Tipo = TipoNo.Funcionario, Equipa = equipa, Funcionario = funcionario };
                noEquipa.Nodes.Add(noFuncionario);
            }
            else if (coordenador && !noFuncionario.Text.Contains("(Coordenador)"))
                noFuncionario.Text = funcionario + " (Coordenador)";
            TreeNode noTarefa = new TreeNode(tarefa.Nome);
            noTarefa.Tag = new DadosNo { Tipo = TipoNo.Tarefa, Equipa = equipa, Funcionario = funcionario, Tarefa = tarefa };
            noFuncionario.Nodes.Add(noTarefa);
        }

        private bool Validar(out string funcionario, out string equipa, out DateTime inicio, out DateTime fim)
        {
            funcionario = cmbFuncionario.Text.Trim();
            equipa = cmbEquipa.Text.Trim();
            inicio = fim = DateTime.MinValue;
            errorProvider1.Clear();
            bool ok = true;
            if (funcionario.Length == 0) { errorProvider1.SetError(cmbFuncionario, "Indique um funcionário."); ok = false; }
            if (equipa.Length == 0) { errorProvider1.SetError(cmbEquipa, "Selecione uma equipa."); ok = false; }
            if (txtTarefa.Text.Trim().Length == 0) { errorProvider1.SetError(txtTarefa, "Indique o nome da tarefa."); ok = false; }
            if (!DateTime.TryParseExact(mskInicio.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out inicio))
            { errorProvider1.SetError(mskInicio, "Data de início inválida. Use dd/mm/aaaa."); ok = false; }
            if (!DateTime.TryParseExact(mskFim.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out fim))
            { errorProvider1.SetError(mskFim, "Data de fim inválida. Use dd/mm/aaaa."); ok = false; }
            if (inicio != DateTime.MinValue && fim != DateTime.MinValue && fim < inicio)
            { errorProvider1.SetError(mskFim, "A data de fim não pode ser anterior à data de início."); ok = false; }
            return ok;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            try
            {
                string funcionario, equipa; DateTime inicio, fim;
                if (!Validar(out funcionario, out equipa, out inicio, out fim))
                { MessageBox.Show("Corrija os campos assinalados antes de continuar.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                TreeNode raiz = EncontrarNo(equipa, TipoNo.Equipa, tvOrganizacao.Nodes);
                TreeNode noFunc = raiz == null ? null : EncontrarNo(funcionario, TipoNo.Funcionario, raiz);
                int numeroFuncionarios = raiz == null ? 0 : raiz.Nodes.Count;
                int numeroTarefas = noFunc == null ? 0 : noFunc.Nodes.Count;
                if (noFunc == null && numeroFuncionarios >= 5)
                { MessageBox.Show("Cada equipa pode ter no máximo 5 funcionários.", "Limite atingido", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                if (noFunc != null && tarefaEmEdicao == null && numeroTarefas >= 3)
                { MessageBox.Show("Cada funcionário pode ter no máximo 3 tarefas simultâneas/atribuídas.", "Limite atingido", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

                if (chkCoordenador.Checked && raiz != null)
                {
                    foreach (TreeNode n in raiz.Nodes)
                        if (n.Text.Contains("(Coordenador)") && !String.Equals(n.Text.Replace(" (Coordenador)", ""), funcionario, StringComparison.OrdinalIgnoreCase))
                        { MessageBox.Show("Esta equipa já tem um coordenador.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
                }

                if (tarefaEmEdicao != null)
                {
                    TreeNode antigo = LocalizarTarefa(tarefaEmEdicao);
                    if (antigo != null) antigo.Remove();
                    tarefaEmEdicao = null;
                }

                if (!funcionarios.Contains(funcionario, StringComparer.OrdinalIgnoreCase))
                {
                    funcionarios.Add(funcionario);
                    cmbFuncionario.Items.Add(funcionario);
                }

                AdicionarNos(equipa, funcionario, new Tarefa {
                    Nome = txtTarefa.Text.Trim(), Descricao = txtDescricao.Text.Trim(),
                    Inicio = inicio, Fim = fim, Responsavel = chkResponsavel.Checked
                }, chkCoordenador.Checked);

                tvOrganizacao.ExpandAll();
                LimparCampos();
            }
            catch (Exception ex) { TratarErro(ex, "Ocorreu um erro ao adicionar a tarefa."); }
            finally { errorProvider1.Clear(); }
        }

        private TreeNode LocalizarTarefa(string nome)
        {
            foreach (TreeNode eq in tvOrganizacao.Nodes)
                foreach (TreeNode f in eq.Nodes)
                    foreach (TreeNode t in f.Nodes)
                    {
                        DadosNo d = t.Tag as DadosNo;
                        if (d != null && d.Tipo == TipoNo.Tarefa && d.Tarefa.Nome == nome) return t;
                    }
            return null;
        }

        private void LimparCampos()
        {
            txtTarefa.Clear(); txtDescricao.Clear(); mskInicio.Clear(); mskFim.Clear();
            chkCoordenador.Checked = chkResponsavel.Checked = false;
            tarefaEmEdicao = null;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                var linhas = new List<string[]>();
                foreach (TreeNode eq in tvOrganizacao.Nodes)
                    foreach (TreeNode f in eq.Nodes)
                        foreach (TreeNode t in f.Nodes)
                        {
                            DadosNo d = t.Tag as DadosNo;
                            if (d == null || d.Tarefa == null) continue;
                            linhas.Add(new string[] { eq.Text, d.Funcionario, d.Tarefa.Nome,
                                d.Tarefa.Inicio.ToString("dd/MM/yyyy"), d.Tarefa.Fim.ToString("dd/MM/yyyy"),
                                f.Text.Contains("(Coordenador)") ? "1" : "0", d.Tarefa.Responsavel ? "1" : "0", d.Tarefa.Descricao });
                        }
                dados.GuardarTarefas(linhas);
                dados.GuardarFuncionarios(funcionarios);
                MessageBox.Show("Dados guardados com sucesso.", "Guardar", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { TratarErro(ex, "Não foi possível guardar os dados."); }
            finally { }
        }

        private void tvOrganizacao_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right) tvOrganizacao.SelectedNode = e.Node;
        }

        private DadosNo Selecionado { get { return tvOrganizacao.SelectedNode == null ? null : tvOrganizacao.SelectedNode.Tag as DadosNo; } }

        private void miEditar_Click(object sender, EventArgs e)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Tarefa) return;
            TreeNode n = tvOrganizacao.SelectedNode;
            cmbFuncionario.Text = d.Funcionario; cmbEquipa.SelectedItem = d.Equipa;
            txtTarefa.Text = d.Tarefa.Nome; txtDescricao.Text = d.Tarefa.Descricao;
            mskInicio.Text = d.Tarefa.Inicio.ToString("ddMMyyyy");
            mskFim.Text = d.Tarefa.Fim.ToString("ddMMyyyy");
            chkResponsavel.Checked = d.Tarefa.Responsavel;
            chkCoordenador.Checked = n.Parent.Text.Contains("(Coordenador)");
            tarefaEmEdicao = d.Tarefa.Nome;
            txtTarefa.Focus();
        }

        private void miApagar_Click(object sender, EventArgs e)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Tarefa) return;
            TreeNode funcionario = tvOrganizacao.SelectedNode.Parent;
            TreeNode equipa = funcionario.Parent;
            tvOrganizacao.SelectedNode.Remove();
            if (funcionario.Nodes.Count == 0) funcionario.Remove();
            if (equipa.Nodes.Count == 0) equipa.Remove();
        }

        private void miDetalhes_Click(object sender, EventArgs e)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Tarefa) return;
            var sb = new StringBuilder();
            sb.AppendLine("Tarefa: " + d.Tarefa.Nome).AppendLine("Funcionário: " + d.Funcionario)
              .AppendLine("Equipa: " + d.Equipa).AppendLine("Início: " + d.Tarefa.Inicio.ToShortDateString())
              .AppendLine("Fim: " + d.Tarefa.Fim.ToShortDateString()).AppendLine("Responsável: " + (d.Tarefa.Responsavel ? "Sim" : "Não"))
              .AppendLine("Descrição: " + d.Tarefa.Descricao).AppendLine().AppendLine("Funcionários e equipas:");
            foreach (TreeNode eq in tvOrganizacao.Nodes)
                foreach (TreeNode f in eq.Nodes) sb.AppendLine("- " + f.Text + " — " + eq.Text);
            MessageBox.Show(sb.ToString(), "Detalhes da tarefa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MostrarTarefasFuncionario(bool ativas)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Funcionario) return;
            TreeNode n = tvOrganizacao.SelectedNode;
            var sb = new StringBuilder();
            foreach (TreeNode t in n.Nodes)
            {
                DadosNo td = t.Tag as DadosNo;
                if (td == null) continue;
                bool ativa = td.Tarefa.Inicio.Date <= DateTime.Today && td.Tarefa.Fim.Date >= DateTime.Today;
                if (!ativas || ativa)
                    sb.AppendLine(td.Tarefa.Nome + " | Equipa: " + d.Equipa + " | " +
                        td.Tarefa.Inicio.ToString("dd/MM/yyyy") + " a " + td.Tarefa.Fim.ToString("dd/MM/yyyy"));
            }
            MessageBox.Show(sb.Length == 0 ? "Não existem tarefas para apresentar." : sb.ToString(),
                ativas ? "Tarefas ativas" : "Lista de tarefas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void miAtivas_Click(object sender, EventArgs e) { MostrarTarefasFuncionario(true); }
        private void miLista_Click(object sender, EventArgs e) { MostrarTarefasFuncionario(false); }

        private void miCarga_Click(object sender, EventArgs e)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Equipa) return;
            var sb = new StringBuilder();
            int total = 0;
            foreach (TreeNode f in tvOrganizacao.SelectedNode.Nodes)
                foreach (TreeNode t in f.Nodes)
                {
                    DadosNo td = t.Tag as DadosNo;
                    if (td != null && td.Tarefa.Inicio.Date <= DateTime.Today && td.Tarefa.Fim.Date >= DateTime.Today)
                    { total++; sb.AppendLine(td.Tarefa.Nome + " | " + td.Funcionario + " | Fim: " + td.Tarefa.Fim.ToString("dd/MM/yyyy")); }
                }
            MessageBox.Show("Tarefas ativas: " + total + Environment.NewLine + sb, "Carga de trabalho", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void miDesempenho_Click(object sender, EventArgs e)
        {
            DadosNo d = Selecionado;
            if (d == null || d.Tipo != TipoNo.Equipa) return;
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("Desempenho da equipa: " + d.Equipa).AppendLine("Gerado em: " + DateTime.Now);
                foreach (TreeNode f in tvOrganizacao.SelectedNode.Nodes)
                    foreach (TreeNode t in f.Nodes)
                    {
                        DadosNo td = t.Tag as DadosNo;
                        if (td != null) sb.AppendLine("Funcionário: " + td.Funcionario + " | Tarefa: " + td.Tarefa.Nome +
                            " | Início: " + td.Tarefa.Inicio.ToString("dd/MM/yyyy") + " | Fim: " +
                            td.Tarefa.Fim.ToString("dd/MM/yyyy") + " | Descrição: " + td.Tarefa.Descricao);
                    }
                string caminho = Path.Combine(dados.PastaDados, "desempenho_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt");
                File.WriteAllText(caminho, sb.ToString(), Encoding.UTF8);
                MessageBox.Show("Relatório criado em:" + Environment.NewLine + caminho, "Desempenho", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { TratarErro(ex, "Não foi possível criar o relatório de desempenho."); }
            finally { }
        }
    }
}
