namespace TasksToDo_INETE
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblFuncionario, lblEquipa, lblTarefa, lblInicio, lblFim, lblDescricao;
        private System.Windows.Forms.ComboBox cmbFuncionario, cmbEquipa;
        private System.Windows.Forms.TextBox txtTarefa, txtDescricao;
        private System.Windows.Forms.CheckBox chkCoordenador, chkResponsavel;
        private System.Windows.Forms.MaskedTextBox mskInicio, mskFim;
        private System.Windows.Forms.TreeView tvOrganizacao;
        private System.Windows.Forms.Button btnAdicionar, btnGuardar;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ContextMenuStrip menuArvore;
        private System.Windows.Forms.ToolStripMenuItem miEditar, miApagar, miDetalhes, miAtivas, miLista, miCarga, miDesempenho;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.lblEquipa = new System.Windows.Forms.Label();
            this.lblTarefa = new System.Windows.Forms.Label();
            this.lblInicio = new System.Windows.Forms.Label();
            this.lblFim = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.cmbFuncionario = new System.Windows.Forms.ComboBox();
            this.cmbEquipa = new System.Windows.Forms.ComboBox();
            this.txtTarefa = new System.Windows.Forms.TextBox();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.chkCoordenador = new System.Windows.Forms.CheckBox();
            this.chkResponsavel = new System.Windows.Forms.CheckBox();
            this.mskInicio = new System.Windows.Forms.MaskedTextBox();
            this.mskFim = new System.Windows.Forms.MaskedTextBox();
            this.tvOrganizacao = new System.Windows.Forms.TreeView();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.menuArvore = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.miEditar = new System.Windows.Forms.ToolStripMenuItem();
            this.miApagar = new System.Windows.Forms.ToolStripMenuItem();
            this.miDetalhes = new System.Windows.Forms.ToolStripMenuItem();
            this.miAtivas = new System.Windows.Forms.ToolStripMenuItem();
            this.miLista = new System.Windows.Forms.ToolStripMenuItem();
            this.miCarga = new System.Windows.Forms.ToolStripMenuItem();
            this.miDesempenho = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.menuArvore.SuspendLayout();
            this.SuspendLayout();
            //
            // Form1
            //
            this.Text = "Tasks To Do - INETE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ClientSize = new System.Drawing.Size(1040, 650);
            this.MinimumSize = new System.Drawing.Size(900, 600);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            //
            // Labels and controls
            //
            this.lblFuncionario.Text = "Funcionário"; this.lblFuncionario.SetBounds(20, 20, 120, 23);
            this.cmbFuncionario.SetBounds(20, 45, 300, 28); this.cmbFuncionario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.lblEquipa.Text = "Equipa"; this.lblEquipa.SetBounds(350, 20, 120, 23);
            this.cmbEquipa.SetBounds(350, 45, 300, 28); this.cmbEquipa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lblTarefa.Text = "Nome da tarefa (máx. 30 caracteres)"; this.lblTarefa.SetBounds(20, 90, 300, 23);
            this.txtTarefa.SetBounds(20, 115, 630, 27); this.txtTarefa.MaxLength = 30;
            this.chkCoordenador.Text = "Coordenador"; this.chkCoordenador.SetBounds(20, 155, 140, 25);
            this.chkResponsavel.Text = "Responsável"; this.chkResponsavel.SetBounds(180, 155, 140, 25);
            this.lblInicio.Text = "Data de início (dd/mm/aaaa)"; this.lblInicio.SetBounds(20, 195, 200, 23);
            this.mskInicio.SetBounds(20, 220, 150, 27); this.mskInicio.Mask = "00/00/0000"; this.mskInicio.ValidatingType = typeof(System.DateTime);
            this.lblFim.Text = "Data de fim (dd/mm/aaaa)"; this.lblFim.SetBounds(190, 195, 200, 23);
            this.mskFim.SetBounds(190, 220, 150, 27); this.mskFim.Mask = "00/00/0000"; this.mskFim.ValidatingType = typeof(System.DateTime);
            this.lblDescricao.Text = "Descrição"; this.lblDescricao.SetBounds(20, 265, 120, 23);
            this.txtDescricao.SetBounds(20, 290, 630, 105); this.txtDescricao.Multiline = true; this.txtDescricao.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.btnAdicionar.Text = "Adicionar"; this.btnAdicionar.SetBounds(20, 415, 150, 38); this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            this.btnGuardar.Text = "Guardar"; this.btnGuardar.SetBounds(185, 415, 150, 38); this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            this.tvOrganizacao.SetBounds(680, 20, 340, 590); this.tvOrganizacao.HideSelection = false; this.tvOrganizacao.ContextMenuStrip = this.menuArvore;
            this.tvOrganizacao.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvOrganizacao_NodeMouseClick);
            this.menuArvore.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.miEditar, this.miApagar, this.miDetalhes, new System.Windows.Forms.ToolStripSeparator(), this.miAtivas, this.miLista, this.miCarga, this.miDesempenho });
            this.miEditar.Text = "Editar"; this.miEditar.Click += new System.EventHandler(this.miEditar_Click);
            this.miApagar.Text = "Apagar"; this.miApagar.Click += new System.EventHandler(this.miApagar_Click);
            this.miDetalhes.Text = "Detalhes"; this.miDetalhes.Click += new System.EventHandler(this.miDetalhes_Click);
            this.miAtivas.Text = "Tarefas ativas"; this.miAtivas.Click += new System.EventHandler(this.miAtivas_Click);
            this.miLista.Text = "Lista de tarefas"; this.miLista.Click += new System.EventHandler(this.miLista_Click);
            this.miCarga.Text = "Carga de trabalho"; this.miCarga.Click += new System.EventHandler(this.miCarga_Click);
            this.miDesempenho.Text = "Desempenho"; this.miDesempenho.Click += new System.EventHandler(this.miDesempenho_Click);
            this.errorProvider1.ContainerControl = this;
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblFuncionario, this.cmbFuncionario, this.lblEquipa, this.cmbEquipa, this.lblTarefa, this.txtTarefa, this.chkCoordenador, this.chkResponsavel, this.lblInicio, this.mskInicio, this.lblFim, this.mskFim, this.lblDescricao, this.txtDescricao, this.btnAdicionar, this.btnGuardar, this.tvOrganizacao });
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.menuArvore.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
