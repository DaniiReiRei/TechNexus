using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace TasksToDo_INETE
{
    public class DataService
    {
        public readonly string PastaDados =
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TasksToDo_INETE");

        public string FicheiroFuncionarios { get { return Path.Combine(PastaDados, "funcionarios.txt"); } }
        public string FicheiroEquipas { get { return Path.Combine(PastaDados, "equipas.txt"); } }
        public string FicheiroArvore { get { return Path.Combine(PastaDados, "tarefas.txt"); } }
        public string FicheiroLogs { get { return Path.Combine(PastaDados, "erros.log"); } }

        public DataService()
        {
            Directory.CreateDirectory(PastaDados);
            CriarSeNaoExistir("funcionarios.txt", "Ana Silva\nJoão Costa\nMaria Santos\nPedro Ferreira\nInês Almeida");
            CriarSeNaoExistir("equipas.txt", "Webdesign\nBases de dados\nRedes\nProgramação\nSistemas");
            CriarSeNaoExistir("tarefas.txt", "");
        }

        private void CriarSeNaoExistir(string nome, string conteudo)
        {
            string caminho = Path.Combine(PastaDados, nome);
            if (!File.Exists(caminho))
                File.WriteAllText(caminho, conteudo, Encoding.UTF8);
        }

        public List<string> LerFuncionarios()
        {
            if (!File.Exists(FicheiroFuncionarios))
                throw new FileNotFoundException("Não foi encontrado o ficheiro de funcionários.", FicheiroFuncionarios);
            return File.ReadAllLines(FicheiroFuncionarios, Encoding.UTF8)
                .Select(x => x.Trim()).Where(x => x.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        public List<string> LerEquipas()
        {
            if (!File.Exists(FicheiroEquipas))
                throw new FileNotFoundException("Não foi encontrado o ficheiro de equipas.", FicheiroEquipas);
            return File.ReadAllLines(FicheiroEquipas, Encoding.UTF8)
                .Select(x => x.Trim()).Where(x => x.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private string B(string s) { return Convert.ToBase64String(Encoding.UTF8.GetBytes(s ?? "")); }
        private string D(string s) { return Encoding.UTF8.GetString(Convert.FromBase64String(s)); }

        public List<string[]> LerTarefas()
        {
            var resultado = new List<string[]>();
            if (!File.Exists(FicheiroArvore)) return resultado;
            foreach (string linha in File.ReadAllLines(FicheiroArvore, Encoding.UTF8))
            {
                if (String.IsNullOrWhiteSpace(linha)) continue;
                string[] p = linha.Split('|');
                if (p.Length != 8) continue;
                try
                {
                    resultado.Add(new string[] { D(p[0]), D(p[1]), D(p[2]), D(p[3]), D(p[4]), p[5], p[6], D(p[7]) });
                }
                catch { RegistarErro(new FormatException("Linha inválida no ficheiro de tarefas: " + linha)); }
            }
            return resultado;
        }

        public void GuardarTarefas(IEnumerable<string[]> linhas)
        {
            var output = new List<string>();
            foreach (string[] p in linhas)
                output.Add(String.Join("|", new string[] { B(p[0]), B(p[1]), B(p[2]), B(p[3]), B(p[4]), p[5], p[6], B(p[7]) }));
            File.WriteAllLines(FicheiroArvore, output, Encoding.UTF8);
        }

        public void GuardarFuncionarios(IEnumerable<string> nomes)
        {
            File.WriteAllLines(FicheiroFuncionarios, nomes.Distinct(StringComparer.OrdinalIgnoreCase), Encoding.UTF8);
        }

        public void RegistarErro(Exception ex)
        {
            try
            {
                Directory.CreateDirectory(PastaDados);
                File.AppendAllText(FicheiroLogs,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + ex.GetType().Name + " | " +
                    ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine + Environment.NewLine,
                    Encoding.UTF8);
            }
            catch { }
        }
    }
}
